function CodeMetrics() {
	 this.metricsArray = {};
	 this.metricsArray.var = new Array();
	 this.metricsArray.fcn = new Array();
	 this.metricsArray.var["rtU"] = {file: "E:\\ketizufile\\slsf_randgen-master_SLforge\\slsf_randgen-master\\slsf\\untitled_ert_rtw\\untitled.c",
	size: 4};
	 this.metricsArray.var["rtY"] = {file: "E:\\ketizufile\\slsf_randgen-master_SLforge\\slsf_randgen-master\\slsf\\untitled_ert_rtw\\untitled.c",
	size: 4};
	 this.metricsArray.fcn["untitled_initialize"] = {file: "E:\\ketizufile\\slsf_randgen-master_SLforge\\slsf_randgen-master\\slsf\\untitled_ert_rtw\\untitled.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["untitled_step"] = {file: "E:\\ketizufile\\slsf_randgen-master_SLforge\\slsf_randgen-master\\slsf\\untitled_ert_rtw\\untitled.c",
	stack: 0,
	stackTotal: 0};
	 this.getMetrics = function(token) { 
		 var data;
		 data = this.metricsArray.var[token];
		 if (!data) {
			 data = this.metricsArray.fcn[token];
			 if (data) data.type = "fcn";
		 } else { 
			 data.type = "var";
		 }
	 return data; }; 
	 this.codeMetricsSummary = '<a href="untitled_metrics.html">Global Memory: 8(bytes) Maximum Stack: 0(bytes)</a>';
	}
CodeMetrics.instance = new CodeMetrics();
